#include <string>
#include <fstream>
#include <iostream>
#include <ftw.h>
#include <sys/stat.h>
std::string dst_root, src_root;
const int ftw_max_fd = 3;

extern "C" int copy_file(const char *, const struct stat *, int);

int copy_file(const char *src_path, const struct stat *sb, int typeflag)
{
    std::string src(src_path);
    std::string dst_path = dst_root + src.substr(src.find(src_root) + src_root.length(), src.length() - src_root.length());
    switch (typeflag)
    {
    case FTW_D: //  src_path is a dir
        mkdir(dst_path.c_str(), sb->st_mode);
        break;
    case FTW_F: //  src_path is a file
        std::ifstream src(src_path, std::ios::binary);
        std::ofstream dst(dst_path, std::ios::binary);
        dst << src.rdbuf();
    }
    return 0;
}

int main(int argc, char **argv)
{
    if (argc != 3)
    {
        std::cout << "[error]: invalid input number" << std::endl;
        return -1;
    }
    dst_root = argv[2], src_root = argv[1];
    if (std::string(argv[1]) == dst_root)
        std::cout
            << "[error]: same src and dst" << std::endl;
    else if (ftw(argv[1], copy_file, ftw_max_fd) == -1)
        std::cout
            << "[error]: copy failed" << std::endl;
    else
        std::cout << "copy success" << std::endl;
    return 0;
}