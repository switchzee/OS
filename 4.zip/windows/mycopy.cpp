#include <windows.h>
#include <direct.h>
#include <iostream>
#include <string>
#define DE_ERROR_MAX 0xb7
#define DE_SAME_FILE 0x71
#define DE_INVALIDFILES 0x7c
using namespace std;
enum STATE
{
    FILE_INPUT_OK = 3,
} state;
void copyFolder(string &src, string &dest)
{
    // requires string terminates with double null.
    // requires full path.(relative is not safe)
    src += '\0', dest += '\0';
    SHFILEOPSTRUCTA fop;
    fop.wFunc = FO_COPY;
    fop.pFrom = src.c_str();
    fop.pTo = dest.c_str();
    try
    {
        int code = SHFileOperationA(&fop);
        switch (code)
        {
        case 0:
            printf("copy success");
            break;
        case DE_ERROR_MAX:
            printf("[error code %d]: MAX_PATH was exceeded during the operation.\n", DE_ERROR_MAX);
            break;
        case DE_SAME_FILE:
            printf("[error code %d]: The source and destination files are the same file.\n", DE_SAME_FILE);
            break;
        case DE_INVALIDFILES:
            printf("[error code %d]: The path in the source or destination or both was invalid.\n", DE_INVALIDFILES);
            break;
        default:
            printf("[error code unknown]: Copy failed for some reason.");
            break;
        }
    }
    catch (exception e)
    {
        printf("[error]: source file does not exist.\n");
    }
}
void makeAbsolute(string &path, bool isSrc = true)
{
    string property = isSrc ? "source" : "destination";
    if (path[1] != ':') //  means it's not absolute
    {
        // relative means in current directory.
        char pBuf[MAX_PATH];
        getcwd(pBuf, MAX_PATH); // get current working directory.
        string curDir(pBuf);
        path = curDir + '\\' + path;
    }
    cout << "[" << property << " path]: " << path << endl;
}
int main(int argc, char *argv[])
{
    if (argc != FILE_INPUT_OK)
    {
        cout << "[error]: invaild number of input" << endl;
        return -1;
    }
    string src(argv[1]), dest(argv[2]);
    makeAbsolute(src), makeAbsolute(dest, false);
    if (src != dest)
        copyFolder(src, dest);
    else
        cout << "[error]: input same file(folder)" << endl;
    return 0;
}