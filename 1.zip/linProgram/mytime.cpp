#include <iostream>
#include <sys/time.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
using namespace std;
#define Calculate(start, end) (end.tv_sec - start.tv_sec) * 1000 + end.tv_usec - start.tv_usec
const string Error = "[Syntax Error]:not input the name of execution file";
const string FailToCreate = "'Creation Error]:fail to create process";
int main(int argc, char *argv[])
{
    // not enough arguments or
    cout << access(argv[1], X_OK);
    if (argc != 2 || access(argv[1], X_OK) == -1)
    {
        cout << Error << "\n";
        return -1;
    }
    struct timeval start, end;
    gettimeofday(&start, NULL);
    int pid = fork();
    if (pid < 0)
    {
        cout << FailToCreate << "\n";
        return -1;
    }
    if (pid == 0)
    {
        execv(argv[1], &argv[1]);
    }
    else
    {
        wait(NULL);
        gettimeofday(&end, NULL);
        cout << "[Success]: total processing time is: " << Calculate(start, end) << "ms\n";
    }
    return 0;
}