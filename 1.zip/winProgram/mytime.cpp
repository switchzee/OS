#include <iostream>
#include <Windows.h>
#include <time.h>
#define Calculate(start, end) \
    ((end.wHour - start.wHour) * 3600 + (end.wMinute - start.wMinute) * 60 + (end.wSecond - start.wSecond)) * 1000 + end.wMilliseconds - start.wMilliseconds
const std::string Error = "[Syntax Error]:not input the name of executable file";
const std::string FailToCreate = "[Creation Error]:Fail to create process";
int main(int argc, char *argv[])
{
    std::string s = argv[1];
    if (argc != 2)
    {
        std::cout << Error << "\n";
        return -1;
    }
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));
    SYSTEMTIME start, end;
    GetSystemTime(&start);      // obtain the system time from beginning.
    if (!CreateProcessA(NULL,    // No module name (use command line)
                       argv[1], // Command line
                       NULL,    // Process handle not inheritable
                       NULL,    // Thread handle not inheritable
                       FALSE,   // Set handle inheritance to FALSE
                       0,       // No creation flags
                       NULL,    // Use parent's environment block
                       NULL,    // Use parent's starting directory
                       &si,     // Pointer to STARTUPINFO structure
                       &pi))
    {
        std::cout << FailToCreate << "\n";
        return -1;
    }
    WaitForSingleObject(pi.hProcess, INFINITE);
    GetSystemTime(&end);
    end.wMilliseconds;
    std::cout << "[Success]:total processing time is: " << Calculate(start, end) << "ms\n";
    // Close process and thread handles.
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    return 0;
}