#include <iostream>
#include <windows.h>
#include <string>
#include <fstream>
#include <psapi.h>
#include <tlhelp32.h>
#include <shlwapi.h>
#include <iomanip>
using namespace std;
void getSystemInformation();  // show system information
void getMemoryInformation();  // show memory information
void getProcessInformation(); // show process information and query a particular process.
void queryProcess();          //show result of querying a particular process.
enum SYS_STATE                // command state
{
    SYS_INFO,     //  show system information
    MEM_INFO,     // show memory information
    PROCESS_INFO, // show process information and query a particular process.
    EXIT,         // exit watcher
    INIT,         //
};
istream &operator>>(istream &in, SYS_STATE &state) // input state: x in {0,1,2,3} is legal, else is EXIT
{
    int x;
    in >> x;
    state = (x > -1 && x < 4) ? SYS_STATE(x) : EXIT;
    return in;
}
int main(void) // command ui
{

    SYS_STATE state = INIT;
    cout << "-------welcome to system memory watcher --------" << endl;
    while (state != EXIT)
    {
        cout << "you can input command:\n"
                "0 - system information\n"
                "1 - memory information\n"
                "2 - process information and query\n"
                "number x not in {0,1,2} - quit\n"
                "------------------------------------------------"
             << endl;
        cin >> state;
        switch (state)
        {
        case SYS_INFO:
            getSystemInformation();
            break;
        case MEM_INFO:
            getMemoryInformation();
            break;
        case PROCESS_INFO:
            getProcessInformation();
            break;
        default:
            state = EXIT;
            break;
        }
    }
    cout << "---------Bye--------------------------------------" << endl;
    return 0;
}
void getSystemInformation()
{
    // make an object pointing to an SYSTEM_INFO object.
    SYSTEM_INFO sysInfo;
    GetSystemInfo(&sysInfo);
    cout << "--------System Information----------" << endl;
    printf("the page size:%d KB\n", (int)sysInfo.dwPageSize / 1024);
    cout << "the highest memory address of a process: " << sysInfo.lpMaximumApplicationAddress << endl;
    cout << "the lowest memory address of a process: " << sysInfo.lpMinimumApplicationAddress << endl;
    cout << "the granularity for the starting address at which virtual memory can be allocated: " << sysInfo.dwAllocationGranularity / 1024 << "KB" << endl;
    cout << "--------System Information end----------" << endl;
}
void getMemoryInformation()
{
    MEMORYSTATUSEX memStatex;
    memStatex.dwLength = sizeof(memStatex);
    GlobalMemoryStatusEx(&memStatex);
    cout << "--------Memeory Information---------" << endl;
    printf("usage of memory:%ld%%\n", memStatex.dwMemoryLoad);
    printf("size of total memory: %.2fGB\n", (float)memStatex.ullTotalPhys / 1024 / 1024 / 1024);
    printf("size of vaild memory: %.2fGB\n", (float)memStatex.ullAvailPhys / 1024 / 1024 / 1024);
    printf("current committed memory limit: %.2fGB\n", (float)memStatex.ullTotalPageFile / 1024 / 1024 / 1024);
    printf("maximum amount of memory the current process can commit: %.2fGB\n", (float)memStatex.ullAvailPageFile / 1024 / 1024 / 1024);
    printf("size of the user-mode portion of the virtual address space of the calling process:%.2fGB\n", (float)memStatex.ullTotalVirtual / 1024 / 1024 / 1024);
    printf("amount of unreserved and uncommitted memory currently of the virtual address space:%.2fGB\n", (float)memStatex.ullAvailVirtual / 1024 / 1024 / 1024);
    cout << "--------Memeory Information---------" << endl;
}
void getProcessInformation()
{
    cout << "--------Process Information---------" << endl;
    PROCESSENTRY32 proEntry;
    proEntry.dwSize = sizeof(proEntry);
    HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    bool bMore = Process32First(hProcessSnap, &proEntry);
    while (bMore)
    {
        HANDLE proInfo = OpenProcess(PROCESS_ALL_ACCESS, false, proEntry.th32ProcessID);
        PROCESS_MEMORY_COUNTERS pmc;
        ZeroMemory(&pmc, sizeof(pmc));
        if (GetProcessMemoryInfo(proInfo, &pmc, sizeof(pmc)))
        {
            cout << "Process ID: ";
            wcout << proEntry.th32ProcessID << endl;
            cout << "Process Name: ";
            wcout << proEntry.szExeFile << endl;
            cout << "Virtial memory size: " << (float)pmc.WorkingSetSize / 1024 << "KB" << endl;
        }
        bMore = Process32Next(hProcessSnap, &proEntry);
    }
    while (true)
    {
        cout << "Do you want to query specific process information?[y/n]" << endl;
        string flag;
        cin >> flag;
        if (flag != "y")
            break;
        queryProcess();
    }
    cout << "--------Process Information end---------" << endl;
}
void queryProcess()
{
    cout << "--------Query Process Information---------" << endl;
    cout << "Input process ID:" << endl;
    int pid;
    cin >> pid;
    HANDLE proInfo = OpenProcess(PROCESS_ALL_ACCESS, false, pid);
    if (proInfo == NULL)
    {
        cout << "[error]:this id does not exit." << endl;
        cout << "-----------Query ends----------------" << endl;
        return;
    }
    // treaverse whole virtual memory and show propety of every memory.
    SYSTEM_INFO sysInfo;
    ZeroMemory(&sysInfo, sizeof(sysInfo));
    GetSystemInfo(&sysInfo);

    MEMORY_BASIC_INFORMATION vms;
    ZeroMemory(&vms, sizeof(vms));

    LPCVOID pBlock = (LPVOID)sysInfo.lpMinimumApplicationAddress;
    while (pBlock < sysInfo.lpMaximumApplicationAddress)
    {
        // format: address-address (size) state[commited|free|reserved]
        if (VirtualQueryEx(proInfo, pBlock, &vms, sizeof(vms)) == sizeof(vms))
        {
            LPCVOID pEnd = (PBYTE)pBlock + vms.RegionSize;
            TCHAR size[MAX_PATH];
            StrFormatByteSize(vms.RegionSize, size, MAX_PATH);
            cout.fill('0');
            cout << hex << setw(8) << (DWORD *)pBlock << "-" << hex << setw(8) << (DWORD *)pEnd << " (" << size << ") ";
            switch (vms.State)
            {
            case MEM_COMMIT:
                printf("commited");
                break;
            case MEM_FREE:
                printf("free");
                break;
            case MEM_RESERVE:
                printf("reserved");
                break;
            }
            TCHAR szFilename[MAX_PATH];
            if (GetModuleFileName(
                    (HMODULE)pBlock,
                    szFilename,
                    MAX_PATH) > 0)
            {
                PathStripPath(szFilename);
                printf(", Module:%s", szFilename);
            }
            printf("\n");
            pBlock = pEnd;
        }
    }
    cout << "-----------Query ends----------------" << endl;
}