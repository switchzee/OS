#include <iostream>
#include <cstring>
#include <unistd.h>
#include <sys/sem.h>
#include <time.h>
#include <sys/shm.h>
#include <sys/wait.h>
#define FULL_ID 1
#define EMPTY_ID 2
#define MUTEX_ID 3
#define SHM_KEY 4
using namespace std;

// every buffer has 10 bytes memory for data.
struct Buffer
{
    char m_data[10];
    int m_dataSize; // size of data this buffer has.
    Buffer() : m_dataSize(0) { memset(m_data, 0, sizeof(m_data)); }
    bool isFull() const { return m_dataSize == 10; }
    bool isEmpty() const { return m_dataSize == 0; }
    void push(char data) { m_data[m_dataSize++] = data; }
    void pop(char &data) { m_data[--m_dataSize] = data; }
    void print() const
    {
        if (m_data)
        {
            for (int i = 0; i < m_dataSize; ++i)
                cout << m_data[i] << " ";
        }
        else
            cout << "None";
        cout << endl;
    }
};
// a pool has 6 buffers.
struct Pool
{
    Buffer m_buffers[6];
    // load data into pool, return true if success.
    void load(int i, char data) { m_buffers[i].push(data); }
    // retrive data from pool, return true if success.
    void retrive(int i, char &recv) { m_buffers[i].pop(recv); }
    // print all buffers in pool
    void printPool() const
    {
        cout << "this is Pool:" << endl;
        for (int i = 0; i < 6; ++i)
            m_buffers[i].print();
        cout << endl;
    }
};
void P(int id)
{
    sembuf sem_op;
    sem_op.sem_num = 0; // operation will perform on the sem_num th semphore in semphore set.
    sem_op.sem_op = -1; // decrease by 1.
    sem_op.sem_flg = 0; // the operation may causes the process to hang waiting for the semaphre to become available.
    semop(id, &sem_op, 1);
}
void V(int id)
{
    sembuf sem_op;
    sem_op.sem_num = 0;
    sem_op.sem_op = 1;
    sem_op.sem_flg = 0;
    semop(id, &sem_op, 1);
}
void getTime()
{
    time_t timer = time(NULL);
    struct tm *tblock = localtime(&timer);
    cout << asctime(tblock) << endl;
}
void consumer(int id)
{
    int Full = semget(FULL_ID, 1, IPC_CREAT);
    int Empty = semget(EMPTY_ID, 1, IPC_CREAT);
    int Mutex = semget(MUTEX_ID, 1, IPC_CREAT);

    int shmid = shmget(SHM_KEY, sizeof(Pool), IPC_CREAT);
    Pool *pool = (Pool *)(shmat(shmid, 0, 0));
    char data;
    for (int i = 0; i < 12; ++i)
    {
        P(Full);
        P(Mutex);
        for (int j = 0; j < 6; ++j)
        {
            if (!pool->m_buffers[j].isEmpty())
            {
                pool->retrive(j, data);
                break;
            }
        }
        getTime();
        cout << "[consumer " << id << " " << i << "]";
        pool->printPool();
        V(Mutex);
        V(Full);
    }
}
void producer(int id)
{
    int Full = semget(FULL_ID, 1, IPC_CREAT);
    int Empty = semget(EMPTY_ID, 1, IPC_CREAT);
    int Mutex = semget(MUTEX_ID, 1, IPC_CREAT);

    int shmid = shmget(SHM_KEY, sizeof(Pool), 0777 | IPC_CREAT);
    Pool *pool = (Pool *)(shmat(shmid, 0, 0));
    for (int i = 0; i < 12; ++i)
    {
        P(Empty);
        P(Mutex);
        for (int j = 0; j < 6; ++j)
        {
            if (!pool->m_buffers[j].isFull())
            {
                pool->load(j, '1');
                break;
            }
        }
        getTime();
        cout << "[producer " << id << " " << i << "]";
        pool->printPool();
        V(Mutex);
        V(Full);
    }
}
int main(void)
{
    int Full = semget(FULL_ID, 1, IPC_CREAT);
    int Empty = semget(EMPTY_ID, 1, IPC_CREAT);
    int Mutex = semget(MUTEX_ID, 1, IPC_CREAT);

    // initialize semaphore
    union sem_command
    {
        int val;
    } empty, full, mutex;
    empty.val = 0;
    full.val = 60;
    mutex.val = 0;
    semctl(Full, 0, SETVAL, full);
    semctl(Empty, 0, SETVAL, empty);
    semctl(Mutex, 0, SETVAL, mutex);

    // shared memory for pool
    int shmid = shmget(SHM_KEY, sizeof(Pool), 0777 | IPC_CREAT);
    if (shmid == -1)
    {
        cout << "fail to create shared memeory" << endl;
        exit(0);
    }
    void *addr = shmat(shmid, 0, 0);
    memset(addr, 0, sizeof(Pool));

    // create 2 producers.
    for (int i = 0; i < 2; ++i)
    {
        if (fork() == 0)
        {
            producer(i);
            exit(0);
        }
    }
    // create 2 consumers.
    for (int i = 2; i < 5; ++i)
    {
        if (fork() == 0)
        {
            consumer(i);
            exit(0);
        }
    }
    // wait for all child process to die.
    while (wait(0) != -1)
        ;
    // close all semaphores.
    semctl(Full, 0, IPC_RMID);
    semctl(Empty, 0, IPC_RMID);
    semctl(Mutex, 0, IPC_RMID);
    shmdt(addr);
}