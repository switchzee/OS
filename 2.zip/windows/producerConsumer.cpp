#include <iostream>
#include <windows.h>
#include <time.h>
using namespace std;
HANDLE processes[5];
// every buffer has 10 bytes memory for data.
struct Buffer
{
    char m_data[10];
    int m_dataSize; // size of data this buffer has.
    Buffer() : m_dataSize(0) { memset(m_data, 0, sizeof(m_data)); }
    bool isFull() const { return m_dataSize == 10; }
    bool isEmpty() const { return m_dataSize == 0; }
    void push(char data) { m_data[m_dataSize++] = data; }
    void pop(char &data) { m_data[--m_dataSize] = data; }
    void print() const
    {
        if (m_dataSize != 0)
            for (int i = 0; i < m_dataSize; ++i)
                cout << m_data[i] << " ";
        else
            cout << "None";
        cout << endl;
    }
};
// a pool has 6 buffers.
struct Pool
{
    Buffer m_buffers[6];
    // load data into pool, return true if success.
    void load(int i, char data) { m_buffers[i].push(data); }
    // retrive data from pool, return true if success.
    void retrive(int i, char &recv) { m_buffers[i].pop(recv); }
    // print all buffers in pool
    void printPool() const
    {
        cout << "this is Pool:" << endl;
        for (int i = 0; i < 6; ++i)
            m_buffers[i].print();
        cout << endl;
    }
};
void StartClone(int nCloneID) //  create processes
{
    char filepath[MAX_PATH];
    GetModuleFileNameA(NULL, filepath, MAX_PATH);

    char command[MAX_PATH]; // command line for identitfy whether the process is consumer or producer.
    sprintf(command, "\"%s\" %d", filepath, nCloneID);

    // printf("%s\n", command);

    STARTUPINFOA si;
    ZeroMemory(reinterpret_cast<void *>(&si), sizeof(si));

    si.cb = sizeof(si);
    PROCESS_INFORMATION pi;

    BOOL isProcessCreated = CreateProcessA(
        filepath,
        command,
        NULL,
        NULL,
        FALSE,
        CREATE_DEFAULT_ERROR_MODE,
        NULL,
        NULL,
        &si,
        &pi);
    if (isProcessCreated)
        processes[nCloneID] = pi.hProcess;
    else
    {
        printf("Error in create process!\n");
        exit(0);
    }
}
void printSystemTime()
{
    time_t timer = time(0);
    struct tm *tblock = localtime(&timer);
    cout << asctime(tblock);
}
void consumer(int id)
{
    char data;
    HANDLE Mutex = CreateMutexA(NULL, FALSE, "MYMUTEX");
    HANDLE Empty = OpenSemaphoreA(SEMAPHORE_ALL_ACCESS, FALSE, "MYEMPTY");
    HANDLE Full = OpenSemaphoreA(SEMAPHORE_ALL_ACCESS, FALSE, "MYFULL");

    HANDLE hMap = OpenFileMappingA(FILE_MAP_ALL_ACCESS, FALSE, "myfilemap");
    LPVOID Data = MapViewOfFile( //文件映射
        hMap,
        FILE_MAP_ALL_ACCESS,
        0,
        0,
        0);
    Pool *pool = reinterpret_cast<Pool *>(Data);

    for (int i = 0; i < 8; ++i)
    {
        // require a full buffer
        WaitForSingleObject(Full, INFINITE);
        WaitForSingleObject(Mutex, INFINITE);
        for (int j = 0; j < 6; j++)
        {
            if (!pool->m_buffers[j].isEmpty())
            {
                pool->retrive(j, data);
                break;
            }
        }
        printSystemTime();
        cout << "[consumer " << id << " " << i << "]";
        pool->printPool();
        ReleaseMutex(Mutex);
        // produce a empty buffer.
        ReleaseSemaphore(Empty, 1, NULL);
        fflush(stdout);
    }
    UnmapViewOfFile(Data);
    Data = NULL;
    CloseHandle(Mutex);
    CloseHandle(Full);
    CloseHandle(Empty);
}
void producer(int id)
{
    // open semaphore and file mapping by their name.
    HANDLE Full = OpenSemaphoreA(SEMAPHORE_ALL_ACCESS, FALSE, "MYFULL");
    HANDLE Empty = OpenSemaphoreA(SEMAPHORE_ALL_ACCESS, FALSE, "MYEMPTY");
    HANDLE Mutex = CreateMutexA(NULL, FALSE, "MYMUTEX");

    HANDLE hMap = OpenFileMappingA(FILE_MAP_ALL_ACCESS, FALSE, "myfilemap");
    LPVOID Data = MapViewOfFile(
        hMap,
        FILE_MAP_ALL_ACCESS,
        0,
        0,
        0);
    Pool *pool = reinterpret_cast<Pool *>(Data);
    // data format: "id: data".
    for (int i = 0; i < 12; ++i)
    {
        // acquire for a empty buffer.
        WaitForSingleObject(Empty, INFINITE);
        // synchronization
        WaitForSingleObject(Mutex, INFINITE);
        for (int j = 0; j < 6; j++)
        {
            if (!pool->m_buffers[j].isFull())
            {
                pool->load(j, '1');
                break;
            }
        }
        printSystemTime();
        cout << "[producer " << id << " " << i << "]";
        pool->printPool();
        fflush(stdout);
        ReleaseMutex(Mutex);
        // produce a full buffer.
        ReleaseSemaphore(Full, 1, NULL);
    }
    UnmapViewOfFile(Data);
    Data = NULL;
    CloseHandle(Mutex);
    CloseHandle(Full);
    CloseHandle(Empty);
}
int main(int argc, char *argv[])
{
    int pindex = 10;
    if (argc > 1)
        sscanf(argv[1], "%d", &pindex); // argv[1] is the index of this process in processes.}
    if (pindex < 2)                     // consumer
        producer(pindex);
    else if (pindex < 5) // producer
        consumer(pindex);
    else //  main process
    {
        // constuct shared memory pool.
        HANDLE hMap = CreateFileMappingA(
            NULL,
            NULL,
            PAGE_READWRITE,
            0,
            sizeof(Pool),
            "myfilemap");

        if (hMap != INVALID_HANDLE_VALUE)
        {
            LPVOID Data = MapViewOfFile(
                hMap,
                FILE_MAP_ALL_ACCESS,
                0,
                0,
                0);
            if (Data != NULL)
            {
                ZeroMemory(Data, sizeof(Pool));
            }
            Pool *pool = reinterpret_cast<Pool *>(Data);
            for (int i = 0; i < 6; ++i)
                pool->m_buffers[i] = Buffer();
            UnmapViewOfFile(Data);
            Data = NULL;
        }

        HANDLE empty = CreateSemaphoreA(NULL, 60, 60, "MYEMPTY");
        HANDLE full = CreateSemaphoreA(NULL, 0, 60, "MYFULL");
        for (int i = 0; i < 5; i++) //create child process
            StartClone(i);          // [0:2] is pro [3:5] is con.
        WaitForMultipleObjects(5, processes, TRUE, INFINITE);
        CloseHandle(empty);
        CloseHandle(full);
        system("pause");
    }
    return 0;
    
}